# Jyotish Marketplace App
This repository contains mobile app, backend, and GitHub workflows for EAS build.