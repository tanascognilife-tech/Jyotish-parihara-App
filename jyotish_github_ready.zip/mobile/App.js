// React Native App Entry Point
console.log('Jyotish App');